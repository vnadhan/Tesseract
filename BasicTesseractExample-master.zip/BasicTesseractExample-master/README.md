# BasicTesseractExample
Shows the simplest way I have found to use tesseract from java

Checkout and run the following, you should see text starting "This is a lot of 12 point. . ." printed to your console

```
mvn clean install from
```


